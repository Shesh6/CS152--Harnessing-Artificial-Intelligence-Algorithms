﻿using System;
using UnityEngine;
using System.Collections;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class RobotController : MonoBehaviour {
		                                                          
    private Vector3 velocity_target;				
	private Vector3 velocity_real;

    public Vector3 error;
    public Vector3 integral;
    public Vector3 integral_clamp;
    public Vector3 output;

    private bool shot = false;
    private bool treasure = false;

    // Initial Paremeters			
    public Vector3 Kp = new Vector3(5,5,5);
	public Vector3 Ki = new Vector3(3,3,3);
	public Vector3 Kd = new Vector3(2,2,2);
    public Vector3 thrust = new Vector3(10, 10, 10);
    public Vector3 force_clamp = new Vector3(10, 10, 10);
    public float speed_rot = 30f;

    // Reference to body
    public Rigidbody rb;

    // References to input fields
    public InputField kp_in;
    public InputField ki_in;
    public InputField kd_in;
    public InputField thrust_in;
    public InputField rot_in;

    // Reference to camera
    public GameObject cam;

    // Reference to the GameController
    private GameObject gc;
    private GenerateBoard gb;

    public Vector3 Divide_Vectors(Vector3 a, Vector3 b)
    {
        Func<float, float> inv = (n) => 1 / (n != 0 ? n : 1);
        var iVec = new Vector3(inv(b.x), inv(b.x), inv(b.z));
        return Vector3.Scale(a, iVec);
    }

    public Vector3 Calculate_PID(Vector3 measured_velocity, Vector3 planned_velocity, float deltaT)
    {
        // Error
        var error = planned_velocity - measured_velocity;
        this.error = error;
        // Integral clamped relative to available thrust
        integral = Vector3.Min(Vector3.Max(-Divide_Vectors(thrust, Ki), integral + (error * deltaT)), Divide_Vectors(thrust, Ki));
        // Derivative
        var derivative = (error - this.error) / deltaT;
        // Scaling
        output = Vector3.Scale(Kp, error) + Vector3.Scale(Ki, integral) + Vector3.Scale(Kd, derivative);
        // Clamping based on available thrust
        output = Vector3.Min(Vector3.Max(-thrust, output), thrust);

        return output;
    }
    
    // Only allow numbers in inputs
    public char NumbersOnly(string input, int charIndex, char inp) { if ((char.IsDigit(inp))||(inp=='.')) {return inp; } return '\0'; }

    // Die
    public void Die() { SceneManager.LoadScene(SceneManager.GetActiveScene().name);  return; }

    // Initialize
    void Start() {
        rb = gameObject.GetComponent<Rigidbody>();
        gc = GameObject.Find("GameController");
        gb = gc.GetComponent<GenerateBoard>();
        kp_in = GameObject.Find("/Canvas/Panel/Kp").GetComponent<InputField>();
        ki_in = GameObject.Find("/Canvas/Panel/Ki").GetComponent<InputField>();
        kd_in = GameObject.Find("/Canvas/Panel/Kd").GetComponent<InputField>();
        thrust_in = GameObject.Find("/Canvas/Panel/Thrust").GetComponent<InputField>();
        rot_in = GameObject.Find("/Canvas/Panel/Rotation").GetComponent<InputField>();

        kp_in.onValidateInput += NumbersOnly;
        ki_in.onValidateInput += NumbersOnly;
        kd_in.onValidateInput += NumbersOnly;
        thrust_in.onValidateInput += NumbersOnly;
        rot_in.onValidateInput += NumbersOnly;
    }
	
	void FixedUpdate() {
        // Main loop, happens every frame

        // Update parameters from input
        if (kp_in.text.Length != 0) { Kp = new Vector3(float.Parse(kp_in.text), float.Parse(kp_in.text), float.Parse(kp_in.text)); }
        if (ki_in.text.Length != 0) { Ki = new Vector3(float.Parse(ki_in.text), float.Parse(ki_in.text), float.Parse(ki_in.text)); }
        if (kd_in.text.Length != 0) { Kd = new Vector3(float.Parse(kd_in.text), float.Parse(kd_in.text), float.Parse(kd_in.text)); }
        if (thrust_in.text.Length != 0) { thrust = new Vector3(float.Parse(thrust_in.text), float.Parse(thrust_in.text), float.Parse(thrust_in.text)); }
        if (rot_in.text.Length != 0) { speed_rot = float.Parse(rot_in.text); }

        // Take input and calculate force
        Vector3 inputs = new Vector3(Input.GetAxisRaw("Horizontal"), 0, Input.GetAxisRaw("Vertical"));

        // OPTIONAL: Track input for and apply TORQUE instead o f Force:
        // var inputs = new Vector3(Input.GetAxisRaw("Pitch"), Input.GetAxisRaw("Yaw"), Input.GetAxisRaw("Roll"));

        velocity_target = Vector3.Scale(inputs, force_clamp);

        // Find real position
        velocity_real = transform.InverseTransformDirection(rb.velocity);

        // OPTIONAL: for TORQUE mode
        // velocity_real = transform.InverseTransformDirection(rb.angularVelocity);

        // Calculate and apply forces over time
        rb.AddRelativeForce(Calculate_PID(velocity_real, velocity_target, Time.fixedDeltaTime) * Time.fixedDeltaTime, ForceMode.Impulse);

        // OPTIONAL: For TORQUE mode
        // rb.AddRelativeTorque(Calculate_PID(velocity_real, velocity_target, Time.fixedDeltaTime) * Time.fixedDeltaTime, ForceMode.Impulse);

        // Rotate camera
        transform.Rotate(new Vector3(0,Input.GetAxisRaw("Power")*Time.deltaTime*speed_rot,0));

        // Shoot
        if ((!shot)&&(Input.GetKey("u")))
        {
            RaycastHit hit;
            if (Physics.Raycast(transform.position, transform.forward, out hit))
            {
                if (hit.transform.gameObject.tag == "Wumpus") { Destroy(hit.transform.gameObject); }
                print("Hit!");
            }
            else { print("Miss!"); }
            shot = true;
        }

        // Check if dead
        int[] coords = gb.Position_to_Coords(transform.position);
        foreach (var tile in gb.pits) { if ((tile[0] == coords[0]) && (tile[1] == coords[1])) { Die(); } };
        if ((gb.wumpus[0] == coords[0]) && (gb.wumpus[1] == coords[1])) { Die(); }

        // Pick up treasure
        if (Input.GetKey("o"))
        {
            if ((gb.treasure[0] == coords[0]) && (gb.treasure[1] == coords[1]))
            {
                Destroy(GameObject.FindGameObjectWithTag("Treasure")) ;
                treasure = true;
            }
        }

        // Check if win
        if ((treasure)&&(coords[0] == 0) && (coords[1] == 0)) { print("win"); Die(); }
    }

}