﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GenerateBoard : MonoBehaviour {

    public GameObject tile_prefab;
    public GameObject wall_prefab;
    public GameObject door_prefab;
    public int board_x;
    public int board_z;
    public int pit_amount = 4;
    public GameObject player_prefab;
    public GameObject stench_prefab;
    public GameObject breeze_prefab;
    public GameObject pit_prefab;
    public GameObject wumpus_prefab;
    public GameObject treasure_prefab;

    public int[] wumpus = new int[] {0,0};
    public int[] treasure = new int[] {0,0};
    public List<int[]> pits = new List<int[]>();
    public HashSet<int[]> stench = new HashSet<int[]>();
    public HashSet<int[]> breeze = new HashSet<int[]>();

    public int[] Position_to_Coords(Vector3 pos)
    {
        int[] coords = new int[] { Mathf.FloorToInt(pos.z - 0.5f), Mathf.FloorToInt(pos.x - 0.5f) };
        return(coords);
    }

    public Vector3 Coords_to_Position(int[] coords)
    {
        Vector3 pos = new Vector3(coords[1]+0.5f,0,coords[0]+0.5f);
        return (pos);
    }

    void EnvEffect(string kind, Vector3 pos)
    {
        GameObject env_pf = breeze_prefab;
        if (kind == "Stench") { env_pf = stench_prefab; }

        for (int i = 0; i < 5; i++)
        {
            for (int j = 0; j < 5; j++)
            {
                for (int k = 0; k < 5; k++)
                {
                    Quaternion breeze_rot = Quaternion.Euler(0, Random.Range(0, 2) * 90, 0);
                    Instantiate(env_pf, new Vector3(i*0.2f,j*0.2f,k*0.2f) + pos, breeze_rot);
                }

            }
        }
    }

    // Initialization
    void Start () {
        // Generate board tiles
        for (float i = 0f; i < board_x; i++)
        {
            for (float j = 0f; j < board_z; j++)
            {
                // Tiles
                Vector3 tile_pos = new Vector3(0.5f + i, 0, 0.5f + j);
                Instantiate(tile_prefab, tile_pos, Quaternion.identity);
                // Extra walls as needed
                if (i == 0)
                {
                    Vector3 door_offset = new Vector3(0, 0.5f, 0.5f);
                    Quaternion door_rot = Quaternion.Euler(0, 90, 0);
                    Instantiate(wall_prefab, tile_pos + door_offset, door_rot);
                }
                if (i == board_x-1)
                {
                    Vector3 door_offset = new Vector3(1, 0.5f, 0.5f);
                    Quaternion door_rot = Quaternion.Euler(0, 90, 0);
                    Instantiate(wall_prefab, tile_pos + door_offset, door_rot);
                }
                if (j == 0)
                {
                    Vector3 door_offset = new Vector3(0.5f, 0.5f, 0);
                    GameObject wall = Instantiate(wall_prefab, tile_pos + door_offset, Quaternion.identity);
                    // Generate Exit Door
                    if (i == 0)
                    {
                        GameObject door = Instantiate(door_prefab, wall.transform.position + new Vector3(0,-0.1f,0.05f), Quaternion.identity);
                        door.transform.parent = wall.transform;
                    }
                }
                if (j == board_z - 1)
                {
                    Vector3 door_offset = new Vector3(0.5f, 0.5f, 1);
                    Instantiate(wall_prefab, tile_pos + door_offset, Quaternion.identity);
                }
            }
        }
        // Set Wumpus and Treasure
        wumpus = new int[] { Random.Range(0, board_z), Random.Range(0, board_x) };
        treasure = new int[] { Random.Range(0, board_z), Random.Range(0, board_x) };
        // Generate Wumpus and Treasure
        Vector3 wum_pos = new Vector3(wumpus[1] + 0.5f, 0, wumpus[0] + 0.5f);
        Vector3 tre_pos = new Vector3(treasure[1] + 0.5f, 0, treasure[0] + 0.5f);
        Instantiate(wumpus_prefab, wum_pos+new Vector3(0.5f,0.04f,0.5f), Quaternion.identity);
        Instantiate(treasure_prefab, tre_pos + new Vector3(0.5f, 0.15f, 0.5f), Quaternion.identity);

        // Set Stench
        stench.Add(new int[] { wumpus[0] + 1, wumpus[1] });
        stench.Add(new int[] { wumpus[0] - 1, wumpus[1] });
        stench.Add(new int[] { wumpus[0], wumpus[1] + 1 });
        stench.Add(new int[] { wumpus[0], wumpus[1] - 1 });

        // Generate Stench
        if (wumpus[0] != 0) { EnvEffect("Stench", new Vector3(0, 0, -1f) + wum_pos); }
        if (wumpus[0] != board_z - 1) { EnvEffect("Stench", new Vector3(0f, 0, 1f) + wum_pos); }
        if (wumpus[1] != 0) { EnvEffect("Stench", new Vector3(-1f, 0, 0) + wum_pos); }
        if (wumpus[1] != board_x - 1) { EnvEffect("Stench", new Vector3(1f, 0, 0) + wum_pos); }

        // Set pits
        for (int i = 0; i < pit_amount; i++)
        {
            int[] pit_loc = new int[] { Random.Range(0, board_z), Random.Range(0, board_x) };
            if (!pits.Contains(pit_loc))
            {
                pits.Add(pit_loc);
                // print("Pit at: " + pits[i][0].ToString() + "," + pits[i][1].ToString());
                // Generate pits
                Instantiate(pit_prefab, new Vector3(pit_loc[1]+1, 0, pit_loc[0]+1), Quaternion.identity);
            }
            else { i--; }
            
        }
        // Set Breeze
        for (int i = 0; i < pits.Count; i++)
        {
            breeze.Add(new int[] { pits[i][0] + 1, pits[i][1] });
            breeze.Add(new int[] { pits[i][0] - 1, pits[i][1] });
            breeze.Add(new int[] { pits[i][0], pits[i][1] + 1 });
            breeze.Add(new int[] { pits[i][0], pits[i][1] - 1 });

            //Generate Breeze
            Vector3 pit_pos = new Vector3(pits[i][1] + 0.5f, 0, pits[i][0] + 0.5f);
            if (pits[i][0] != 0) { EnvEffect("Breeze",new Vector3(0, 0, -1f) + pit_pos); }
            if (pits[i][0] != board_z - 1) { EnvEffect("Breeze", new Vector3(0f, 0, 1f) + pit_pos); }
            if (pits[i][1] != 0) { EnvEffect("Breeze", new Vector3(-1f, 0, 0) + pit_pos); }
            if (pits[i][1] != board_x - 1){ EnvEffect("Breeze", new Vector3(1f, 0, 0) + pit_pos); }
        }
        // Generate Player
        Instantiate(player_prefab, new Vector3(1,0.05f,0.5f), Quaternion.identity);
    }
}